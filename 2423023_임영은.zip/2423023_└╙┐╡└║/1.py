# 사용자로부터 정수 5개를 입력 받기
print (input("1번 째 값을 입력하세요: "))
print (input("2번 째 값을 입력하세요: "))
print (input("3번 째 값을 입력하세요: "))
print (input("4번 째 값을 입력하세요: "))
print (input("5번 째 값을 입력하세요: "))

range (input("1번 째 값을 입력하세요: "))